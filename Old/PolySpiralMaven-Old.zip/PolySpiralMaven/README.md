# PolySpiralMaven Demo

This is a simple example of how to compile and execute a Compose Desktop application
purely in Maven without using Jetbrains Compose Gradle plugin.

## Run on JVM

   `mvn clean`
   
   `mvn compile`
   
   `mvn exec:java`
