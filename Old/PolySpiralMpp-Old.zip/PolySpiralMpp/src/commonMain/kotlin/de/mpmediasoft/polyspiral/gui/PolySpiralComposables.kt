//package de.mpmediasoft.polyspiral.gui
//
//import androidx.compose.runtime.Composable
//import androidx.compose.ui.Modifier
//
//@Composable
//expect fun DataTooltipArea(
//    dataString: String,
//    modifier: Modifier = Modifier,
//    content: @Composable () -> Unit
//)
//
// This currently result in a compiler error on macOS and iOS.
// java.lang.IllegalStateException: IrBasedSimpleFunctionDescriptor: FUN name:DataTooltipArea visibility:public modality:FINAL <> (dataString:kotlin.String, modifier:androidx.compose.ui.Modifier, content:kotlin.Function2<androidx.compose.runtime.Composer, kotlin.Int, kotlin.Unit>) returnType:kotlin.Unit [expect]